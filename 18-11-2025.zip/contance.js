module.exports.SIGN_EVENTS = {
    PENDING: 'pending',
    SENT: 'sent',
    DELIVERED: 'delivered',
    VOIDED: 'voided',
    COMPLETED: 'completed',
}